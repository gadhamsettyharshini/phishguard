# PhishGuard — AI Phishing & Deepfake Detector

A three-part system that analyzes emails, URLs, and images for social-engineering and manipulation red flags:

- **`backend/`** — Node.js/Express analysis engine. NLP heuristics for phishing language, typosquatting/homoglyph URL detection, and lightweight image forensics (metadata + Error Level Analysis). Optionally blends in a Gemini AI second opinion for email text.
- **`web-app/`** — React + Vite + Tailwind dashboard. Paste an email, a URL, or upload an image and get a risk score with explained findings.
- **`extension/`** — Manifest V3 Chrome extension. Adds a live risk badge next to open Gmail messages, flags risky outbound links on any page, and includes a popup for quick manual scans.

All three point at the same backend, so you only run the detection logic once.

## Why heuristics instead of a black-box model

Every score comes with a plain-English reason ("domain resembles paypal.com, edit distance 1", "contains credential-request language"). That's a deliberate choice: a security tool that can't explain *why* it flagged something is hard to trust and hard to debug. The one place this project uses a model (Gemini, optional) is layered on top of the heuristics as a second opinion, not a replacement for them.

**Scope honesty on deepfakes:** true deepfake detection (GAN fingerprinting, face-warp artifacts, temporal inconsistency in video) needs a trained CNN and real labeled data — that's a research project on its own. What's implemented here is image *forensics*: EXIF metadata inspection and Error Level Analysis, the same first-pass checks a human investigator runs. Treat the media analyzer's output as "signs of editing to look into further," not a deepfake verdict. The findings text says this explicitly so nobody mistakes it for more than it is.

## Setup

### 1. Backend

```bash
cd backend
npm install
cp .env.example .env   # optional: add GEMINI_API_KEY for the AI second opinion on emails
npm start
```

Runs on `http://localhost:5001`. Works fully on heuristics alone with no API key.

### 2. Web app

```bash
cd web-app
npm install
npm run dev
```

Opens on `http://localhost:5173`, proxies `/api/*` to the backend.

### 3. Browser extension

1. Open `chrome://extensions`
2. Enable **Developer mode** (top right)
3. Click **Load unpacked** and select the `extension/` folder
4. Make sure the backend is running — the popup shows a green dot when it's reachable
5. Open Gmail and click into any message: a risk badge appears next to the subject line
6. On any other page, risky outbound links get a small ⚠ marker, and if the page itself looks like a phishing domain, a badge appears top-right

## API reference

| Endpoint | Method | Body | Returns |
|---|---|---|---|
| `/api/analyze/email` | POST | `{ from, subject, body, html }` | `{ score, riskLevel, findings, urls, linkMismatches, aiOpinion }` |
| `/api/analyze/url` | POST | `{ url }` | `{ score, riskLevel, findings, host }` |
| `/api/analyze/media` | POST (multipart) | `file` | `{ score, riskLevel, findings, disclaimer }` |

`score` is 0–100. `riskLevel` is `low` (<35), `medium` (35–69), or `high` (≥70).

## What the email/URL engine checks

- Sender display-name spoofing (claims "PayPal" but domain isn't paypal.com)
- Urgency, fear, authority, reward, and credential-request language patterns
- Typosquatted domains (Levenshtein distance against a known-brand list)
- Homoglyph substitution (`paypa1.com`, `rnicrosoft.com`)
- Brand names disguised as subdomains (`paypal.com.verify-secure.xyz`)
- Suspicious TLDs, raw-IP URLs, URL shorteners, excessive hyphens, no HTTPS
- HTML emails where the displayed link text doesn't match the real href

## Known limitations

- The known-brands and suspicious-TLD lists are starting points, not exhaustive — extend `backend/src/utils/knownBrands.js` as needed.
- Gmail's DOM is unofficial and changes over time; if the badge stops appearing, the selectors in `gmail-scanner.js` need re-checking against the current Gmail markup.
- Media analysis only supports images; video/audio deepfake detection isn't implemented (see scope note above).
- This is a heuristic engine, not a trained classifier — it will have both false positives and false negatives like any rule-based system. It's a strong signal, not a guarantee.

## Stack

React 18, Vite, Tailwind CSS, Node.js, Express, Google Gemini API (optional), sharp, exifr, Manifest V3.
