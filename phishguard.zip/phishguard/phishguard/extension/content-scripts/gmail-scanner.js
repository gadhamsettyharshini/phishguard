// Scans the currently-open Gmail message for phishing indicators and injects
// a risk badge next to the subject line.
//
// NOTE: Gmail's DOM is unofficial and changes over time — these selectors
// (`h2.hP` for subject, `span.gD` for sender, `div.a3s.aiL` for body) are the
// ones commonly relied on by Gmail extensions as of 2026, but if Gmail ships
// a redesign, these will need to be re-inspected via devtools and updated.

const BADGE_ID = "phishguard-badge";
let lastAnalyzedSubject = null;
let debounceTimer = null;

function extractOpenEmail() {
  const subjectEl = document.querySelector("h2.hP");
  const senderEl = document.querySelector("span.gD");
  const bodyEl = document.querySelector("div.a3s.aiL");

  if (!subjectEl || !bodyEl) return null;

  const subject = subjectEl.innerText.trim();
  const senderName = senderEl?.getAttribute("name") || "";
  const senderEmail = senderEl?.getAttribute("email") || "";
  const from = senderEmail ? `${senderName} <${senderEmail}>` : "";
  const html = bodyEl.innerHTML;
  const body = bodyEl.innerText;

  return { subjectEl, subject, from, body, html };
}

function riskColor(level) {
  if (level === "high") return "#FF4D5E";
  if (level === "medium") return "#FFB020";
  return "#2FE6A0";
}

function injectBadge(subjectEl, state) {
  document.getElementById(BADGE_ID)?.remove();

  const badge = document.createElement("span");
  badge.id = BADGE_ID;
  badge.style.cssText = `
    display: inline-flex; align-items: center; gap: 6px;
    margin-left: 12px; padding: 4px 10px; border-radius: 999px;
    font-family: monospace; font-size: 11px; font-weight: 600;
    vertical-align: middle; cursor: default;
    border: 1px solid ${riskColor(state.level)};
    color: ${riskColor(state.level)};
    background: ${riskColor(state.level)}1a;
  `;
  badge.textContent = state.label;
  badge.title = state.tooltip || "";
  subjectEl.appendChild(badge);
}

async function analyzeCurrentEmail() {
  const email = extractOpenEmail();
  if (!email || email.subject === lastAnalyzedSubject) return;
  lastAnalyzedSubject = email.subject;

  injectBadge(email.subjectEl, { level: "low", label: "PHISHGUARD · SCANNING…" });

  chrome.runtime.sendMessage(
    {
      type: "ANALYZE_EMAIL",
      payload: { from: email.from, subject: email.subject, body: email.body, html: email.html }
    },
    (response) => {
      if (!response?.ok) {
        injectBadge(email.subjectEl, {
          level: "low",
          label: "PHISHGUARD · OFFLINE",
          tooltip: response?.error || "Could not reach the PhishGuard backend. Is it running on localhost:5001?"
        });
        return;
      }
      const { score, riskLevel, findings } = response.result;
      const topFinding = findings[0]?.message || "No red flags detected.";
      injectBadge(email.subjectEl, {
        level: riskLevel,
        label: `PHISHGUARD · ${score}/100`,
        tooltip: topFinding
      });
    }
  );
}

const observer = new MutationObserver(() => {
  clearTimeout(debounceTimer);
  debounceTimer = setTimeout(analyzeCurrentEmail, 600);
});

observer.observe(document.body, { childList: true, subtree: true });
