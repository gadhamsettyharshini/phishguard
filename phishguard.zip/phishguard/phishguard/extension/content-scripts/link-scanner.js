// Runs on every page (except Gmail, which has its own scanner). Two jobs:
//   1. Check the current page's own URL and show a floating badge if it
//      looks like a phishing domain.
//   2. Scan outbound links on the page and mark risky ones inline.

function riskColor(level) {
  if (level === "high") return "#FF4D5E";
  if (level === "medium") return "#FFB020";
  return "#2FE6A0";
}

function checkCurrentPage() {
  chrome.runtime.sendMessage(
    { type: "ANALYZE_URL", payload: { url: window.location.href } },
    (response) => {
      if (!response?.ok) return; // backend offline — fail silently on page scans
      const { score, riskLevel, findings } = response.result;
      if (riskLevel === "low") return; // only surface when there's something worth seeing

      const badge = document.createElement("div");
      badge.style.cssText = `
        position: fixed; top: 16px; right: 16px; z-index: 2147483647;
        display: flex; align-items: center; gap: 8px;
        padding: 10px 14px; border-radius: 10px;
        font-family: monospace; font-size: 12px; font-weight: 600;
        color: #E7EAF0; background: #12161F;
        border: 1px solid ${riskColor(riskLevel)};
        box-shadow: 0 4px 20px rgba(0,0,0,0.4);
      `;
      badge.innerHTML = `<span style="color:${riskColor(riskLevel)}">●</span> PhishGuard: this site scored ${score}/100 — ${findings[0]?.message || "review before entering data"}`;
      document.body.appendChild(badge);
      setTimeout(() => badge.remove(), 12000);
    }
  );
}

function markRiskyLinks() {
  const anchors = [...document.querySelectorAll("a[href^='http']")];
  const uniqueHosts = new Map(); // host -> [anchor elements]

  for (const a of anchors) {
    try {
      const host = new URL(a.href).hostname;
      if (host === window.location.hostname) continue; // skip internal links
      if (!uniqueHosts.has(host)) uniqueHosts.set(host, []);
      uniqueHosts.get(host).push(a);
    } catch {
      /* malformed href, skip */
    }
  }

  // Cap how many distinct hosts we check per page to keep this lightweight.
  const hostsToCheck = [...uniqueHosts.keys()].slice(0, 40);

  for (const host of hostsToCheck) {
    const anchor = uniqueHosts.get(host)[0];
    chrome.runtime.sendMessage(
      { type: "ANALYZE_URL", payload: { url: anchor.href } },
      (response) => {
        if (!response?.ok) return;
        const { score, riskLevel } = response.result;
        if (riskLevel === "low") return;

        for (const el of uniqueHosts.get(host)) {
          const flag = document.createElement("span");
          flag.textContent = " ⚠";
          flag.title = `PhishGuard: ${score}/100 risk — ${host}`;
          flag.style.cssText = `color: ${riskColor(riskLevel)}; font-weight: bold; cursor: help;`;
          el.appendChild(flag);
        }
      }
    );
  }
}

checkCurrentPage();
// Give the page a moment to finish rendering dynamic content before scanning links.
setTimeout(markRiskyLinks, 1000);
