const input = document.getElementById("input");
const scanBtn = document.getElementById("scan-btn");
const errorEl = document.getElementById("error");
const resultEl = document.getElementById("result");
const scoreEl = document.getElementById("score");
const riskLabelEl = document.getElementById("risk-label");
const findingsEl = document.getElementById("findings");
const statusDot = document.getElementById("status-dot");
const apiBaseInput = document.getElementById("api-base");

const RISK_COLORS = { high: "#FF4D5E", medium: "#FFB020", low: "#2FE6A0" };
const URL_REGEX = /^\s*https?:\/\/\S+\s*$/i;

function setStatus(online) {
  statusDot.classList.remove("online", "offline");
  statusDot.classList.add(online ? "online" : "offline");
}

async function init() {
  const { apiBase } = await chrome.storage.local.get("apiBase");
  apiBaseInput.value = apiBase || "http://localhost:5001";

  chrome.runtime.sendMessage({ type: "PING_BACKEND" }, (res) => setStatus(!!res?.ok));
}

apiBaseInput.addEventListener("change", () => {
  chrome.storage.local.set({ apiBase: apiBaseInput.value.trim() });
  chrome.runtime.sendMessage({ type: "PING_BACKEND" }, (res) => setStatus(!!res?.ok));
});

function renderResult({ score, riskLevel, findings }) {
  resultEl.classList.remove("hidden");
  const color = RISK_COLORS[riskLevel] || "#8892A6";
  scoreEl.textContent = score;
  scoreEl.style.color = color;
  riskLabelEl.textContent = `${riskLevel.toUpperCase()} RISK`;

  findingsEl.innerHTML = "";
  if (!findings.length) {
    const li = document.createElement("li");
    li.textContent = "No red flags detected.";
    li.style.color = "#2FE6A0";
    findingsEl.appendChild(li);
  } else {
    for (const f of findings) {
      const li = document.createElement("li");
      li.style.color = RISK_COLORS[f.severity] || "#8892A6";
      li.textContent = f.message;
      findingsEl.appendChild(li);
    }
  }
}

scanBtn.addEventListener("click", () => {
  const value = input.value.trim();
  errorEl.textContent = "";
  resultEl.classList.add("hidden");

  if (!value) {
    errorEl.textContent = "Paste something to scan first.";
    return;
  }

  scanBtn.disabled = true;
  scanBtn.textContent = "Scanning…";

  const isUrl = URL_REGEX.test(value);
  const message = isUrl
    ? { type: "ANALYZE_URL", payload: { url: value } }
    : { type: "ANALYZE_EMAIL", payload: { body: value } };

  chrome.runtime.sendMessage(message, (response) => {
    scanBtn.disabled = false;
    scanBtn.textContent = "Scan";
    if (!response?.ok) {
      errorEl.textContent = response?.error || "Could not reach the PhishGuard backend.";
      setStatus(false);
      return;
    }
    setStatus(true);
    renderResult(response.result);
  });
});

init();
