// Service worker: central place that talks to the PhishGuard backend so
// content scripts don't need host permissions for every possible API origin.

const DEFAULT_API_BASE = "http://localhost:5001";

async function getApiBase() {
  const { apiBase } = await chrome.storage.local.get("apiBase");
  return apiBase || DEFAULT_API_BASE;
}

async function callBackend(path, options) {
  const apiBase = await getApiBase();
  const res = await fetch(`${apiBase}${path}`, options);
  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    throw new Error(body.error || `Request failed (${res.status})`);
  }
  return res.json();
}

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  (async () => {
    try {
      if (message.type === "ANALYZE_EMAIL") {
        const result = await callBackend("/api/analyze/email", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(message.payload)
        });
        sendResponse({ ok: true, result });
      } else if (message.type === "ANALYZE_URL") {
        const result = await callBackend("/api/analyze/url", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(message.payload)
        });
        sendResponse({ ok: true, result });
      } else if (message.type === "PING_BACKEND") {
        const apiBase = await getApiBase();
        const res = await fetch(`${apiBase}/health`).catch(() => null);
        sendResponse({ ok: !!res?.ok });
      }
    } catch (err) {
      sendResponse({ ok: false, error: err.message });
    }
  })();
  return true; // keep the message channel open for the async response
});
