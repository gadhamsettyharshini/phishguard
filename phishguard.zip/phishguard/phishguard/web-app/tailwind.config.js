/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,jsx}"],
  theme: {
    extend: {
      colors: {
        ink: "#0A0D12",
        panel: "#12161F",
        line: "#232937",
        signal: {
          safe: "#2FE6A0",
          warn: "#FFB020",
          danger: "#FF4D5E",
          info: "#5B8CFF"
        },
        mist: "#8892A6"
      },
      fontFamily: {
        display: ["'Space Grotesk'", "sans-serif"],
        mono: ["'JetBrains Mono'", "monospace"],
        body: ["'Inter'", "sans-serif"]
      }
    }
  },
  plugins: []
};
