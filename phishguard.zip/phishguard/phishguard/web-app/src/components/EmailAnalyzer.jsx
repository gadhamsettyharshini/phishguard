import { useState } from "react";
import RiskGauge from "./RiskGauge.jsx";
import FindingsList from "./FindingsList.jsx";

const SAMPLE = {
  from: "PayPal Support <support@paypa1-security.com>",
  subject: "Urgent: Your account has been suspended",
  body: "Dear valued member, we detected unusual activity on your account. Act now and verify your account within 24 hours or it will be permanently closed.\n\nClick here: http://secure-paypa1-login.verify-account.xyz"
};

export default function EmailAnalyzer({ apiBase }) {
  const [form, setForm] = useState({ from: "", subject: "", body: "" });
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const update = (field) => (e) => setForm({ ...form, [field]: e.target.value });

  const runAnalysis = async () => {
    if (!form.body.trim() && !form.subject.trim()) {
      setError("Paste the email subject or body first.");
      return;
    }
    setError(null);
    setLoading(true);
    setResult(null);
    try {
      const res = await fetch(`${apiBase}/api/analyze/email`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form)
      });
      if (!res.ok) throw new Error((await res.json()).error || "Analysis failed");
      setResult(await res.json());
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const loadSample = () => setForm(SAMPLE);

  return (
    <div className="grid md:grid-cols-2 gap-8">
      <div className="flex flex-col gap-4">
        <div className="flex items-center justify-between">
          <label className="mono text-xs uppercase tracking-widest text-mist">From header</label>
          <button onClick={loadSample} className="mono text-xs text-signal-info hover:underline">
            load sample phishing email
          </button>
        </div>
        <input
          value={form.from}
          onChange={update("from")}
          placeholder='e.g. "PayPal Support <support@paypa1-security.com>"'
          className="bg-panel border border-line rounded-lg px-4 py-3 text-sm outline-none focus:border-signal-info transition-colors"
        />
        <label className="mono text-xs uppercase tracking-widest text-mist">Subject</label>
        <input
          value={form.subject}
          onChange={update("subject")}
          className="bg-panel border border-line rounded-lg px-4 py-3 text-sm outline-none focus:border-signal-info transition-colors"
        />
        <label className="mono text-xs uppercase tracking-widest text-mist">Body</label>
        <textarea
          value={form.body}
          onChange={update("body")}
          rows={9}
          placeholder="Paste the full email body here…"
          className="bg-panel border border-line rounded-lg px-4 py-3 text-sm outline-none focus:border-signal-info transition-colors resize-none"
        />
        {error && <p className="text-signal-danger text-sm">{error}</p>}
        <button
          onClick={runAnalysis}
          disabled={loading}
          className="mt-1 bg-signal-info/10 border border-signal-info text-signal-info rounded-lg py-3 font-medium hover:bg-signal-info/20 transition-colors disabled:opacity-50"
        >
          {loading ? "Analyzing…" : "Analyze email"}
        </button>
      </div>

      <div className="bg-panel border border-line rounded-xl p-6 flex flex-col items-center gap-6 min-h-[420px]">
        {!result && !loading && (
          <div className="flex-1 flex items-center justify-center text-mist text-sm text-center px-6">
            Results will appear here once you run an analysis.
          </div>
        )}
        {(result || loading) && (
          <>
            <RiskGauge score={result?.score ?? 0} scanning={loading} />
            {result && (
              <div className="w-full fade-up">
                <h3 className="mono text-xs uppercase tracking-widest text-mist mb-3">Findings</h3>
                <FindingsList findings={result.findings} />
                {result.aiOpinion && (
                  <div className="mt-5 pt-4 border-t border-line">
                    <h3 className="mono text-xs uppercase tracking-widest text-mist mb-2">AI second opinion</h3>
                    <p className="text-sm text-mist">{result.aiOpinion.reasoning}</p>
                  </div>
                )}
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}
