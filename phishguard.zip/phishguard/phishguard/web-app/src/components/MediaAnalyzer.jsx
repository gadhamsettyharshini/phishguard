import { useState, useRef } from "react";
import RiskGauge from "./RiskGauge.jsx";
import FindingsList from "./FindingsList.jsx";

export default function MediaAnalyzer({ apiBase }) {
  const [file, setFile] = useState(null);
  const [preview, setPreview] = useState(null);
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const inputRef = useRef(null);

  const onFile = (f) => {
    if (!f) return;
    setFile(f);
    setResult(null);
    setError(null);
    if (f.type.startsWith("image/")) setPreview(URL.createObjectURL(f));
    else setPreview(null);
  };

  const runAnalysis = async () => {
    if (!file) {
      setError("Upload an image first.");
      return;
    }
    setError(null);
    setLoading(true);
    setResult(null);
    try {
      const formData = new FormData();
      formData.append("file", file);
      const res = await fetch(`${apiBase}/api/analyze/media`, { method: "POST", body: formData });
      if (!res.ok) throw new Error((await res.json()).error || "Analysis failed");
      setResult(await res.json());
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="grid md:grid-cols-2 gap-8">
      <div className="flex flex-col gap-4">
        <div
          onClick={() => inputRef.current.click()}
          onDragOver={(e) => e.preventDefault()}
          onDrop={(e) => { e.preventDefault(); onFile(e.dataTransfer.files[0]); }}
          className="border-2 border-dashed border-line rounded-xl h-64 flex items-center justify-center cursor-pointer hover:border-signal-info transition-colors overflow-hidden"
        >
          {preview ? (
            <img src={preview} alt="preview" className="w-full h-full object-contain" />
          ) : (
            <p className="text-mist text-sm text-center px-6">
              Drop an image here, or click to browse<br />
              <span className="text-xs">JPG, PNG · max 15MB</span>
            </p>
          )}
        </div>
        <input
          ref={inputRef}
          type="file"
          accept="image/*"
          className="hidden"
          onChange={(e) => onFile(e.target.files[0])}
        />
        {error && <p className="text-signal-danger text-sm">{error}</p>}
        <button
          onClick={runAnalysis}
          disabled={loading}
          className="bg-signal-info/10 border border-signal-info text-signal-info rounded-lg py-3 font-medium hover:bg-signal-info/20 transition-colors disabled:opacity-50"
        >
          {loading ? "Analyzing…" : "Analyze image"}
        </button>
        <p className="text-xs text-mist leading-relaxed">
          This runs metadata inspection and Error Level Analysis to surface signs of editing.
          It is a forensics heuristic, not a trained deepfake classifier — treat results as a
          signal to investigate further, not a verdict.
        </p>
      </div>

      <div className="bg-panel border border-line rounded-xl p-6 flex flex-col items-center gap-6 min-h-[420px]">
        {!result && !loading && (
          <div className="flex-1 flex items-center justify-center text-mist text-sm text-center px-6">
            Results will appear here once you run an analysis.
          </div>
        )}
        {(result || loading) && (
          <>
            <RiskGauge score={result?.score ?? 0} scanning={loading} />
            {result && (
              <div className="w-full fade-up">
                <h3 className="mono text-xs uppercase tracking-widest text-mist mb-3">Findings</h3>
                <FindingsList findings={result.findings} emptyLabel="No editing artifacts detected." />
                {result.disclaimer && (
                  <p className="text-xs text-mist mt-4 pt-4 border-t border-line">{result.disclaimer}</p>
                )}
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}
