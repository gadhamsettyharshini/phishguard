import { useState } from "react";
import RiskGauge from "./RiskGauge.jsx";
import FindingsList from "./FindingsList.jsx";

export default function UrlAnalyzer({ apiBase }) {
  const [url, setUrl] = useState("");
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const runAnalysis = async () => {
    if (!url.trim()) {
      setError("Enter a URL first.");
      return;
    }
    setError(null);
    setLoading(true);
    setResult(null);
    try {
      const res = await fetch(`${apiBase}/api/analyze/url`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ url })
      });
      if (!res.ok) throw new Error((await res.json()).error || "Analysis failed");
      setResult(await res.json());
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex flex-col items-center gap-8 max-w-xl mx-auto">
      <div className="w-full flex gap-3">
        <input
          value={url}
          onChange={(e) => setUrl(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && runAnalysis()}
          placeholder="Paste a URL, e.g. http://secure-paypa1-login.verify-account.xyz"
          className="mono flex-1 bg-panel border border-line rounded-lg px-4 py-3 text-sm outline-none focus:border-signal-info transition-colors"
        />
        <button
          onClick={runAnalysis}
          disabled={loading}
          className="bg-signal-info/10 border border-signal-info text-signal-info rounded-lg px-6 font-medium hover:bg-signal-info/20 transition-colors disabled:opacity-50 shrink-0"
        >
          {loading ? "Scanning…" : "Scan"}
        </button>
      </div>
      {error && <p className="text-signal-danger text-sm">{error}</p>}

      {(result || loading) && (
        <div className="w-full bg-panel border border-line rounded-xl p-6 flex flex-col items-center gap-6">
          <RiskGauge score={result?.score ?? 0} scanning={loading} />
          {result && (
            <div className="w-full fade-up">
              {result.host && (
                <p className="mono text-xs text-mist text-center mb-4">{result.host}</p>
              )}
              <h3 className="mono text-xs uppercase tracking-widest text-mist mb-3">Findings</h3>
              <FindingsList findings={result.findings} emptyLabel="No phishing indicators found." />
            </div>
          )}
        </div>
      )}
    </div>
  );
}
