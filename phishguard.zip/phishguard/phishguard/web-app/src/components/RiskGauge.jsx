const RADIUS = 80;
const CIRCUMFERENCE = Math.PI * RADIUS; // half circle arc length

function colorFor(score) {
  if (score >= 70) return "#FF4D5E";
  if (score >= 35) return "#FFB020";
  return "#2FE6A0";
}

function labelFor(score) {
  if (score >= 70) return "HIGH RISK";
  if (score >= 35) return "MEDIUM RISK";
  return "LOW RISK";
}

export default function RiskGauge({ score = 0, scanning = false, size = 220 }) {
  const pct = Math.max(0, Math.min(100, score)) / 100;
  const offset = CIRCUMFERENCE * (1 - pct);
  const color = colorFor(score);

  return (
    <div className="relative flex flex-col items-center" style={{ width: size }}>
      <svg viewBox="0 0 200 110" width={size} height={size * 0.55}>
        <path
          d="M 20 100 A 80 80 0 0 1 180 100"
          fill="none"
          stroke="#232937"
          strokeWidth="14"
          strokeLinecap="round"
        />
        <path
          d="M 20 100 A 80 80 0 0 1 180 100"
          fill="none"
          stroke={color}
          strokeWidth="14"
          strokeLinecap="round"
          strokeDasharray={CIRCUMFERENCE}
          strokeDashoffset={offset}
          className="gauge-arc"
          style={{ "--gauge-start": CIRCUMFERENCE, "--gauge-end": offset, filter: `drop-shadow(0 0 6px ${color}88)` }}
        />
      </svg>
      <div className="absolute top-[58%] flex flex-col items-center">
        <span className="mono text-4xl font-medium" style={{ color }}>
          {scanning ? "—" : Math.round(score)}
        </span>
        <span className="mono text-[10px] tracking-[0.2em] text-mist mt-1">
          {scanning ? "SCANNING…" : labelFor(score)}
        </span>
      </div>
      {scanning && (
        <div className="absolute inset-0 overflow-hidden rounded-full pointer-events-none">
          <div className="scan-sweep" />
        </div>
      )}
    </div>
  );
}
