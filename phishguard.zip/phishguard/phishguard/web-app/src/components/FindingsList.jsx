const SEVERITY_STYLES = {
  high: { dot: "bg-signal-danger", text: "text-signal-danger" },
  medium: { dot: "bg-signal-warn", text: "text-signal-warn" },
  low: { dot: "bg-signal-info", text: "text-signal-info" },
  info: { dot: "bg-mist", text: "text-mist" },
  warning: { dot: "bg-signal-warn", text: "text-signal-warn" }
};

export default function FindingsList({ findings = [], emptyLabel = "No red flags detected." }) {
  if (!findings.length) {
    return (
      <p className="mono text-sm text-signal-safe flex items-center gap-2">
        <span className="w-1.5 h-1.5 rounded-full bg-signal-safe inline-block" />
        {emptyLabel}
      </p>
    );
  }

  return (
    <ul className="flex flex-col gap-3">
      {findings.map((f, i) => {
        const style = SEVERITY_STYLES[f.severity] || SEVERITY_STYLES.info;
        return (
          <li key={i} className="flex items-start gap-3 fade-up" style={{ animationDelay: `${i * 60}ms` }}>
            <span className={`w-1.5 h-1.5 rounded-full mt-2 shrink-0 ${style.dot}`} />
            <p className="text-sm text-mist leading-relaxed">
              <span className={`mono text-[10px] uppercase tracking-wider mr-2 ${style.text}`}>
                {f.severity}
              </span>
              {f.message}
            </p>
          </li>
        );
      })}
    </ul>
  );
}
