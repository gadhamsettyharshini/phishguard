import { useState } from "react";
import EmailAnalyzer from "./components/EmailAnalyzer.jsx";
import UrlAnalyzer from "./components/UrlAnalyzer.jsx";
import MediaAnalyzer from "./components/MediaAnalyzer.jsx";

const API_BASE = import.meta.env.VITE_API_BASE || "http://localhost:5001";

const TABS = [
  { id: "email", label: "Email" },
  { id: "url", label: "URL" },
  { id: "media", label: "Media" }
];

export default function App() {
  const [tab, setTab] = useState("email");

  return (
    <div className="min-h-screen flex flex-col">
      <header className="border-b border-line">
        <div className="max-w-5xl mx-auto px-6 py-6 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-md bg-signal-info/15 border border-signal-info/40 flex items-center justify-center">
              <span className="text-signal-info text-sm">◈</span>
            </div>
            <div>
              <h1 className="display font-semibold text-lg leading-none">PhishGuard</h1>
              <p className="mono text-[10px] text-mist tracking-widest mt-1">SOCIAL ENGINEERING DETECTOR</p>
            </div>
          </div>
          <a
            href="https://github.com"
            className="mono text-xs text-mist hover:text-signal-info transition-colors"
          >
            v1.0 · heuristics + AI
          </a>
        </div>
      </header>

      <main className="flex-1 max-w-5xl mx-auto w-full px-6 py-10">
        <nav className="flex gap-1 mb-10 bg-panel border border-line rounded-lg p-1 w-fit">
          {TABS.map((t) => (
            <button
              key={t.id}
              onClick={() => setTab(t.id)}
              className={`mono text-xs uppercase tracking-widest px-5 py-2.5 rounded-md transition-colors ${
                tab === t.id ? "bg-signal-info/15 text-signal-info" : "text-mist hover:text-white"
              }`}
            >
              {t.label}
            </button>
          ))}
        </nav>

        {tab === "email" && <EmailAnalyzer apiBase={API_BASE} />}
        {tab === "url" && <UrlAnalyzer apiBase={API_BASE} />}
        {tab === "media" && <MediaAnalyzer apiBase={API_BASE} />}
      </main>

      <footer className="border-t border-line py-6">
        <p className="mono text-[10px] text-mist text-center tracking-widest">
          RUNS LOCALLY · NOTHING YOU ANALYZE LEAVES YOUR MACHINE UNLESS AI MODE IS ENABLED
        </p>
      </footer>
    </div>
  );
}
