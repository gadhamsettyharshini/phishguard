import { KNOWN_BRANDS, SUSPICIOUS_TLDS, URL_SHORTENERS } from "../utils/knownBrands.js";
import { levenshtein, clampScore, riskLabel } from "../utils/heuristics.js";

const IP_URL_REGEX = /^(\d{1,3}\.){3}\d{1,3}$/;
// Characters commonly swapped in homograph / lookalike attacks.
// NOTE: applied in a single simultaneous pass (see simplifyHomoglyphs) so
// substitutions can't chain and undo each other (e.g. 1->l then l->1).
const HOMOGLYPH_MAP = { "0": "o", "1": "l", "rn": "m", "vv": "w" };
const HOMOGLYPH_REGEX = new RegExp(Object.keys(HOMOGLYPH_MAP).sort((a, b) => b.length - a.length).join("|"), "g");

function simplifyHomoglyphs(host) {
  return host.replace(HOMOGLYPH_REGEX, match => HOMOGLYPH_MAP[match]);
}

function normalizedHost(url) {
  try {
    return new URL(url.startsWith("http") ? url : `http://${url}`).hostname.toLowerCase();
  } catch {
    return null;
  }
}

function checkTyposquat(host) {
  let closest = null;
  let closestDistance = Infinity;
  for (const brand of KNOWN_BRANDS) {
    if (host === brand) return { exactMatch: brand };
    const dist = levenshtein(host, brand);
    // only worth flagging if it's close AND not just a legit subdomain
    if (dist < closestDistance && !host.endsWith(`.${brand}`)) {
      closestDistance = dist;
      closest = brand;
    }
  }
  if (closest && closestDistance > 0 && closestDistance <= 2 && Math.abs(host.length - closest.length) <= 3) {
    return { lookalikeOf: closest, distance: closestDistance };
  }
  return null;
}

function checkHomoglyphSubstitution(host) {
  const simplified = simplifyHomoglyphs(host);
  for (const brand of KNOWN_BRANDS) {
    const brandRoot = brand.split(".")[0];
    if (simplified.includes(brandRoot) && !host.includes(brandRoot)) {
      return brand;
    }
  }
  return null;
}

/**
 * Analyzes a single URL for phishing / social-engineering red flags.
 * Returns a risk score (0-100) plus a list of human-readable findings.
 */
export function analyzeUrl(rawUrl) {
  const findings = [];
  let score = 0;
  const host = normalizedHost(rawUrl);

  if (!host) {
    return {
      url: rawUrl,
      score: 60,
      riskLevel: "medium",
      findings: [{ severity: "warning", message: "URL could not be parsed — malformed or obfuscated." }]
    };
  }

  // 1. Raw IP address instead of a domain name
  const hostWithoutPort = host.split(":")[0];
  if (IP_URL_REGEX.test(hostWithoutPort)) {
    score += 30;
    findings.push({ severity: "high", message: `Links directly to a raw IP address (${hostWithoutPort}) instead of a domain name.` });
  }

  // 2. Suspicious / cheap TLD
  const tldHit = SUSPICIOUS_TLDS.find(tld => host.endsWith(tld));
  if (tldHit) {
    score += 15;
    findings.push({ severity: "medium", message: `Uses a top-level domain (${tldHit}) frequently abused for disposable phishing sites.` });
  }

  // 3. URL shortener — hides real destination
  if (URL_SHORTENERS.some(s => host === s)) {
    score += 12;
    findings.push({ severity: "medium", message: "Uses a URL shortener, which conceals the true destination." });
  }

  // 4. Typosquatting against known brands
  const typo = checkTyposquat(host);
  if (typo?.exactMatch) {
    // legit known domain — reduce baseline risk
    score -= 10;
  } else if (typo?.lookalikeOf) {
    score += 35;
    findings.push({
      severity: "high",
      message: `Domain "${host}" closely resembles "${typo.lookalikeOf}" (edit distance ${typo.distance}) — likely typosquatting.`
    });
  }

  // 5. Homoglyph substitution (e.g. "paypa1.com", "rnicrosoft.com")
  const homoglyphBrand = checkHomoglyphSubstitution(host);
  if (homoglyphBrand) {
    score += 30;
    findings.push({ severity: "high", message: `Uses character substitution to visually mimic "${homoglyphBrand}".` });
  }

  // 6. Excessive subdomains — e.g. secure-login.paypal.com.verify-account.xyz
  const labelCount = host.split(".").length;
  if (labelCount >= 5) {
    score += 15;
    findings.push({ severity: "medium", message: "Unusually long subdomain chain, often used to bury a fake brand name before the real domain." });
  } else {
    // check if a known brand name appears as a subdomain label rather than the actual registered domain
    const labels = host.split(".");
    const registeredDomain = labels.slice(-2).join(".");
    const brandInSubdomain = KNOWN_BRANDS.find(b => {
      const brandRoot = b.split(".")[0];
      return labels.slice(0, -2).some(l => l.includes(brandRoot)) && registeredDomain !== b;
    });
    if (brandInSubdomain) {
      score += 30;
      findings.push({ severity: "high", message: `Brand name "${brandInSubdomain.split(".")[0]}" appears as a subdomain rather than the real domain — classic disguise technique.` });
    }
  }

  // 7. Hyphen-heavy hostnames (e.g. secure-paypal-login-verify.com)
  const hyphenCount = (host.match(/-/g) || []).length;
  if (hyphenCount >= 3) {
    score += 10;
    findings.push({ severity: "low", message: "Hostname contains an unusually high number of hyphens, common in generated phishing domains." });
  }

  // 8. No HTTPS
  if (rawUrl.startsWith("http://")) {
    score += 8;
    findings.push({ severity: "low", message: "Connection is not encrypted (http, not https)." });
  }

  score = clampScore(score);
  return { url: rawUrl, host, score, riskLevel: riskLabel(score), findings };
}

export function analyzeUrls(urls) {
  return urls.map(analyzeUrl);
}
