import { scanLanguageSignals, extractUrls, findLinkTextMismatches, clampScore, riskLabel } from "../utils/heuristics.js";
import { analyzeUrls } from "./urlAnalyzer.js";
import { KNOWN_BRANDS } from "../utils/knownBrands.js";
import { levenshtein } from "../utils/heuristics.js";

/** Checks whether the sender's display name claims a brand the domain doesn't match. */
function checkSenderSpoofing(fromHeader) {
  if (!fromHeader) return null;
  const match = fromHeader.match(/^(.*?)<(.+?)>$/);
  if (!match) return null;
  const displayName = match[1].trim().toLowerCase();
  const email = match[2].trim().toLowerCase();
  const domain = email.split("@")[1] || "";

  for (const brand of KNOWN_BRANDS) {
    const brandRoot = brand.split(".")[0];
    if (displayName.includes(brandRoot) && !domain.endsWith(brand)) {
      return { claimedBrand: brandRoot, actualDomain: domain };
    }
  }
  return null;
}

/** Optional: ask Gemini for a nuanced read on tone/intent that pure heuristics miss. */
async function getAiOpinion(emailText, apiKey) {
  if (!apiKey) return null;
  try {
    const { GoogleGenerativeAI } = await import("@google/generative-ai");
    const genAI = new GoogleGenerativeAI(apiKey);
    const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" });
    const prompt = `You are a phishing detection assistant. Analyze this email strictly for social engineering / phishing indicators (not spam/marketing). Respond ONLY with JSON, no markdown fences, in this exact shape:
{"aiRiskScore": <0-100 integer>, "reasoning": "<one or two sentence explanation>", "likelyIntent": "<credential theft | financial fraud | malware delivery | none | other>"}

Email:
"""
${emailText.slice(0, 6000)}
"""`;
    const result = await model.generateContent(prompt);
    const raw = result.response.text().replace(/```json|```/g, "").trim();
    return JSON.parse(raw);
  } catch (err) {
    console.error("Gemini analysis failed:", err.message);
    return null;
  }
}

/**
 * Full email analysis pipeline:
 *  1. Sender spoofing check
 *  2. NLP language-signal scan (urgency, fear, authority, reward, credential requests)
 *  3. Embedded URL extraction + analysis
 *  4. Display-text vs actual-href mismatch detection (HTML emails)
 *  5. Optional Gemini AI second opinion, blended into the final score
 */
export async function analyzeEmail({ from, subject = "", body = "", html = "" }, apiKey) {
  const findings = [];
  let score = 0;

  const spoof = checkSenderSpoofing(from);
  if (spoof) {
    score += 30;
    findings.push({
      severity: "high",
      message: `Sender name claims to be "${spoof.claimedBrand}" but the email domain is "${spoof.actualDomain}".`
    });
  }

  const fullText = `${subject}\n${body}`;
  const { score: langScore, findings: langFindings } = scanLanguageSignals(fullText);
  score += langScore;
  for (const f of langFindings) {
    findings.push({
      severity: f.category === "credentialRequest" || f.category === "fear" ? "high" : "medium",
      message: `Contains ${f.category.replace(/([A-Z])/g, " $1").toLowerCase()} language: "${f.matched.join('", "')}"`
    });
  }

  const urls = extractUrls(fullText.concat(" ", html));
  const urlResults = analyzeUrls(urls);
  const worstUrl = urlResults.reduce((max, u) => (u.score > (max?.score ?? -1) ? u : max), null);
  if (worstUrl && worstUrl.score >= 35) {
    score += Math.min(30, worstUrl.score * 0.4);
  }

  let linkMismatches = [];
  if (html) {
    linkMismatches = findLinkTextMismatches(html);
    if (linkMismatches.length) {
      score += 20;
      findings.push({
        severity: "high",
        message: `${linkMismatches.length} link(s) display one URL but actually point somewhere else.`
      });
    }
  }

  // Generic subject-line greeting instead of a name is a weak but real signal
  if (/^\s*(dear (customer|user|valued member|sir\/madam))/i.test(fullText)) {
    score += 5;
    findings.push({ severity: "low", message: "Uses a generic greeting instead of your actual name." });
  }

  let aiOpinion = null;
  if (apiKey) {
    aiOpinion = await getAiOpinion(fullText, apiKey);
    if (aiOpinion?.aiRiskScore != null) {
      // Blend: 65% heuristic score, 35% AI score — heuristics stay primary/explainable,
      // AI catches nuance (tone, context) heuristics can't.
      score = score * 0.65 + aiOpinion.aiRiskScore * 0.35;
    }
  }

  score = clampScore(score);
  return {
    score,
    riskLevel: riskLabel(score),
    findings,
    urls: urlResults,
    linkMismatches,
    aiOpinion
  };
}
