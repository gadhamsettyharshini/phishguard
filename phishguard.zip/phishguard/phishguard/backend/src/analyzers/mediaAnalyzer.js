import sharp from "sharp";
import exifr from "exifr";
import { clampScore, riskLabel } from "../utils/heuristics.js";

/**
 * IMPORTANT SCOPE NOTE:
 * True deepfake detection (GAN-fingerprinting, face-warping artifact detection,
 * temporal inconsistency in video) requires a trained CNN model and is out of
 * scope for a heuristic-only engine. This analyzer instead does lightweight
 * *media forensics* — the kind of checks a human investigator does first:
 *   1. Metadata inspection (missing/stripped EXIF, editing software signatures)
 *   2. Error Level Analysis (ELA) — recompresses the image and diffs it against
 *      the original to surface regions that were edited/spliced at a different
 *      compression history than the rest of the image.
 *   3. Basic resolution/aspect-ratio sanity checks common in face-swap crops.
 * Treat the output as "signs of editing" risk, not a deepfake verdict.
 */

const EDITING_SOFTWARE_SIGNATURES = [
  "photoshop", "gimp", "faceapp", "facesw", "deepfacelab", "reface",
  "lightroom", "affinity photo"
];

async function runErrorLevelAnalysis(buffer) {
  // Recompress at a known quality and diff against the original.
  const original = await sharp(buffer).ensureAlpha().raw().toBuffer({ resolveWithObject: true });
  const recompressed = await sharp(buffer)
    .jpeg({ quality: 90 })
    .ensureAlpha()
    .raw()
    .toBuffer({ resolveWithObject: true });

  if (original.data.length !== recompressed.data.length) {
    return { elaScore: 0, note: "Could not run ELA (format mismatch after recompression)." };
  }

  let totalDiff = 0;
  let maxDiff = 0;
  const { width, height } = original.info;
  const blockSize = 16;
  const blockDiffs = [];

  for (let by = 0; by < height; by += blockSize) {
    for (let bx = 0; bx < width; bx += blockSize) {
      let blockSum = 0;
      let count = 0;
      for (let y = by; y < Math.min(by + blockSize, height); y++) {
        for (let x = bx; x < Math.min(bx + blockSize, width); x++) {
          const idx = (y * width + x) * 4;
          const diff = Math.abs(original.data[idx] - recompressed.data[idx]);
          blockSum += diff;
          totalDiff += diff;
          maxDiff = Math.max(maxDiff, diff);
          count++;
        }
      }
      blockDiffs.push(blockSum / count);
    }
  }

  const avgDiff = totalDiff / (width * height);
  const mean = blockDiffs.reduce((a, b) => a + b, 0) / blockDiffs.length;
  const variance = blockDiffs.reduce((a, b) => a + (b - mean) ** 2, 0) / blockDiffs.length;
  const stdDev = Math.sqrt(variance);

  // High variance across blocks = some regions compress very differently from
  // others, suggesting a spliced/edited region. This is a heuristic signal,
  // not proof.
  const elaScore = Math.min(100, (stdDev / (mean + 1)) * 40 + avgDiff * 2);
  return { elaScore, avgDiff: Number(avgDiff.toFixed(2)), stdDev: Number(stdDev.toFixed(2)) };
}

export async function analyzeMedia(buffer, mimeType) {
  const findings = [];
  let score = 0;

  if (!mimeType.startsWith("image/")) {
    return {
      score: 0,
      riskLevel: "unsupported",
      findings: [{ severity: "info", message: "Video/audio deepfake detection requires a trained model and is not supported in this heuristic engine yet. Image analysis is available." }]
    };
  }

  // 1. Metadata inspection
  let metadata = null;
  try {
    metadata = await exifr.parse(buffer, true);
  } catch {
    metadata = null;
  }

  if (!metadata || Object.keys(metadata).length === 0) {
    score += 15;
    findings.push({ severity: "medium", message: "No EXIF metadata found — either stripped intentionally or a screenshot/re-saved image. Common after editing or when images are run through generation tools." });
  } else {
    const software = (metadata.Software || "").toLowerCase();
    const hit = EDITING_SOFTWARE_SIGNATURES.find(sig => software.includes(sig));
    if (hit) {
      score += 25;
      findings.push({ severity: "high", message: `Metadata shows the image was processed with "${metadata.Software}".` });
    }
    if (!metadata.Make && !metadata.Model) {
      score += 8;
      findings.push({ severity: "low", message: "No camera make/model in metadata — image likely did not come directly from a camera." });
    }
  }

  // 2. Error Level Analysis
  try {
    const ela = await runErrorLevelAnalysis(buffer);
    if (ela.elaScore) {
      score += Math.min(35, ela.elaScore * 0.35);
      if (ela.elaScore > 40) {
        findings.push({ severity: "high", message: "Error Level Analysis shows inconsistent compression across regions of the image — a common sign of splicing or localized editing." });
      } else if (ela.elaScore > 20) {
        findings.push({ severity: "medium", message: "Error Level Analysis shows mild compression inconsistency — could indicate light editing, or just normal recompression artifacts." });
      }
    }
  } catch (err) {
    findings.push({ severity: "info", message: "Error Level Analysis could not be completed for this file format." });
  }

  score = clampScore(score);
  return {
    score,
    riskLevel: riskLabel(score),
    findings,
    disclaimer: "Heuristic media-forensics signal only — not a confirmed deepfake verdict. For high-stakes verification, cross-check with reverse image search and the original source."
  };
}
