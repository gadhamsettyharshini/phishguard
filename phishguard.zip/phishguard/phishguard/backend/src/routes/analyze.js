import express from "express";
import multer from "multer";
import { analyzeEmail } from "../analyzers/emailAnalyzer.js";
import { analyzeUrl } from "../analyzers/urlAnalyzer.js";
import { analyzeMedia } from "../analyzers/mediaAnalyzer.js";

const router = express.Router();
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 15 * 1024 * 1024 } });

router.post("/email", async (req, res) => {
  try {
    const { from, subject, body, html } = req.body;
    if (!body && !html) {
      return res.status(400).json({ error: "Provide at least 'body' or 'html' text to analyze." });
    }
    const result = await analyzeEmail({ from, subject, body, html }, process.env.GEMINI_API_KEY);
    res.json(result);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Email analysis failed." });
  }
});

router.post("/url", (req, res) => {
  try {
    const { url } = req.body;
    if (!url) return res.status(400).json({ error: "Provide a 'url' field." });
    res.json(analyzeUrl(url));
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "URL analysis failed." });
  }
});

router.post("/media", upload.single("file"), async (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ error: "Upload a file under the 'file' field." });
    const result = await analyzeMedia(req.file.buffer, req.file.mimetype);
    res.json(result);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Media analysis failed." });
  }
});

export default router;
