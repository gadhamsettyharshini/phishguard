// Commonly impersonated brands in phishing campaigns.
// Used for typosquatting / lookalike-domain detection (Levenshtein distance check).
export const KNOWN_BRANDS = [
  "google.com", "gmail.com", "microsoft.com", "outlook.com", "office365.com",
  "apple.com", "icloud.com", "amazon.com", "paypal.com", "netflix.com",
  "facebook.com", "instagram.com", "whatsapp.com", "linkedin.com", "twitter.com",
  "x.com", "chase.com", "bankofamerica.com", "wellsfargo.com", "citibank.com",
  "hdfcbank.com", "icicibank.com", "sbi.co.in", "irctc.co.in", "flipkart.com",
  "github.com", "dropbox.com", "adobe.com", "yahoo.com", "steamcommunity.com",
  "coinbase.com", "binance.com", "supabase.com", "spotify.com"
];

// Suspicious TLDs frequently abused for cheap, disposable phishing infrastructure.
export const SUSPICIOUS_TLDS = [
  ".xyz", ".top", ".club", ".work", ".click", ".link", ".gq", ".tk", ".ml",
  ".cf", ".ga", ".loan", ".zip", ".mov", ".rest", ".icu", ".fit", ".cam"
];

// Popular URL shorteners — not malicious by themselves, but they hide the
// real destination, which is a common phishing evasion technique.
export const URL_SHORTENERS = [
  "bit.ly", "tinyurl.com", "t.co", "goo.gl", "ow.ly", "is.gd", "buff.ly",
  "rebrand.ly", "cutt.ly", "shorturl.at", "tiny.cc"
];
