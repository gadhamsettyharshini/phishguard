// Core reusable heuristics shared across analyzers.

/** Classic Levenshtein edit distance between two strings. */
export function levenshtein(a, b) {
  const m = a.length, n = b.length;
  const dp = Array.from({ length: m + 1 }, () => new Array(n + 1).fill(0));
  for (let i = 0; i <= m; i++) dp[i][0] = i;
  for (let j = 0; j <= n; j++) dp[0][j] = j;
  for (let i = 1; i <= m; i++) {
    for (let j = 1; j <= n; j++) {
      dp[i][j] = a[i - 1] === b[j - 1]
        ? dp[i - 1][j - 1]
        : 1 + Math.min(dp[i - 1][j - 1], dp[i - 1][j], dp[i][j - 1]);
    }
  }
  return dp[m][n];
}

/** Social-engineering language cues, grouped by manipulation tactic. */
export const LANGUAGE_SIGNALS = {
  urgency: [
    "act now", "immediately", "urgent", "within 24 hours", "expires today",
    "final notice", "last chance", "time-sensitive", "right away", "asap"
  ],
  fear: [
    "account suspended", "account will be closed", "unusual activity",
    "unauthorized access", "your account has been locked", "suspicious login",
    "legal action", "you have been reported", "payment failed"
  ],
  authority: [
    "irs", "government", "official notice", "law enforcement", "court order",
    "your bank", "security team", "billing department"
  ],
  reward: [
    "you have won", "claim your prize", "free gift", "you are selected",
    "congratulations", "lottery", "cash reward"
  ],
  credentialRequest: [
    "verify your account", "confirm your password", "update your billing",
    "enter your ssn", "confirm your identity", "re-enter your credentials",
    "click here to verify", "login to confirm"
  ]
};

/** Rough scoring weight per detected signal category. */
export const SIGNAL_WEIGHTS = {
  urgency: 8,
  fear: 10,
  authority: 6,
  reward: 9,
  credentialRequest: 14
};

/** Scans free text for social-engineering language patterns. */
export function scanLanguageSignals(text) {
  const lower = text.toLowerCase();
  const findings = [];
  let score = 0;

  for (const [category, phrases] of Object.entries(LANGUAGE_SIGNALS)) {
    const matched = phrases.filter(p => lower.includes(p));
    if (matched.length) {
      score += SIGNAL_WEIGHTS[category] * Math.min(matched.length, 3);
      findings.push({ category, matched });
    }
  }
  return { score, findings };
}

/** Extracts all URLs from a block of text. */
export function extractUrls(text) {
  const regex = /(https?:\/\/[^\s"'<>]+)/gi;
  return [...new Set(text.match(regex) || [])];
}

/** Detects mismatched display text vs actual href, e.g. anchor tags in HTML email bodies. */
export function findLinkTextMismatches(html) {
  const anchorRegex = /<a[^>]+href=["']([^"']+)["'][^>]*>([^<]*)<\/a>/gi;
  const mismatches = [];
  let match;
  while ((match = anchorRegex.exec(html)) !== null) {
    const href = match[1];
    const displayText = match[2].trim();
    const displayLooksLikeUrl = /^(https?:\/\/|www\.)/i.test(displayText);
    if (displayLooksLikeUrl) {
      try {
        const hrefHost = new URL(href).hostname.replace(/^www\./, "");
        const displayHost = displayText.replace(/^https?:\/\//i, "").replace(/^www\./, "").split("/")[0];
        if (hrefHost && displayHost && !hrefHost.includes(displayHost) && !displayHost.includes(hrefHost)) {
          mismatches.push({ href, displayText });
        }
      } catch {
        // malformed href — flag as suspicious on its own
        mismatches.push({ href, displayText });
      }
    }
  }
  return mismatches;
}

export function clampScore(score) {
  return Math.max(0, Math.min(100, Math.round(score)));
}

export function riskLabel(score) {
  if (score >= 70) return "high";
  if (score >= 35) return "medium";
  return "low";
}
