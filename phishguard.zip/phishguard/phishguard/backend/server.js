import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import analyzeRoutes from "./src/routes/analyze.js";

dotenv.config();

const app = express();
const PORT = process.env.PORT || 5001;

app.use(cors()); // extension + web app both call this API cross-origin
app.use(express.json({ limit: "2mb" }));

app.get("/health", (_req, res) => res.json({ status: "ok", service: "phishguard-backend" }));
app.use("/api/analyze", analyzeRoutes);

app.listen(PORT, () => {
  console.log(`PhishGuard backend running on http://localhost:${PORT}`);
  if (!process.env.GEMINI_API_KEY) {
    console.log("  (GEMINI_API_KEY not set — running on heuristics only, no AI second opinion)");
  }
});
